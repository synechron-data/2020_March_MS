﻿using ShoppingCartService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShoppingCartService.DBContext
{
    public class ShoppingCartContext
    {
        private HashSet<ShoppingCartItem> items = new HashSet<ShoppingCartItem>();

        public int UserId { get; }

        public IEnumerable<ShoppingCartItem> Items { get { return items; } }

        public ShoppingCartContext(int userId)
        {
            this.UserId = userId;
        }

        public IEnumerable<ShoppingCartItem> AddItems(IEnumerable<ShoppingCartItem> items) {
            foreach (var item in items)
            {
                this.items.Add(item);
            }

            return this.items;
        }
    }
}
