﻿using ShoppingCartService.DBContext;
using ShoppingCartService.ProductCatalogeClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShoppingCartService.Repository
{
    public class ShoppingCartRepository : IShoppingCartRepository
    {
        private readonly IProductCatalogeClient _pcClient;

        public ShoppingCartRepository(IProductCatalogeClient pcClient)
        {
            this._pcClient = pcClient;
        }

        private static readonly Dictionary<int, ShoppingCartContext> database
           = new Dictionary<int, ShoppingCartContext>();

        public ShoppingCartContext Get(int userID)
        {
            if (!database.ContainsKey(userID))
                database[userID] = new ShoppingCartContext(userID);
            return database[userID];
        }

        public async Task<ShoppingCartContext> Save(int userID, int[] ids)
        {
            var shoppingCartItems = await _pcClient.GetSPItems(ids);

            var db = this.Get(userID);
            db.AddItems(shoppingCartItems);
            return db;
        }
    }
}
