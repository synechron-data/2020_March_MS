﻿using ShoppingCartService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShoppingCartService.ProductCatalogeClient
{
    public class ProductCatalogeClient : IProductCatalogeClient
    {
        public Task<IEnumerable<ShoppingCartItem>> GetSPItems(int[] pIds)
        {
            throw new NotImplementedException();
        }
    }
}
