﻿using ShoppingCartService.Models.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShoppingCartService.Models
{
    public class ShoppingCartItem
    {
        public int ProductCatalogueId { get; set; }
        public string ProductName { get; set; }
        public string Description { get; set; }
        public Money Price { get; set; }

        public ShoppingCartItem(int productCatalogueId, string productName, string description, Money price)
        {
            this.ProductCatalogueId = productCatalogueId;
            this.ProductName = productName;
            this.Description = description;
            this.Price = price;
        }

        public override bool Equals(object obj)
        {
            if (obj == null || GetType() != obj.GetType())
            {
                return false;
            }

            var that = obj as ShoppingCartItem;
            return this.ProductCatalogueId.Equals(that.ProductCatalogueId);
        }

        public override int GetHashCode()
        {
            return this.ProductCatalogueId.GetHashCode();
        }
    }
}
