﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ShoppingCartService.Repository;

namespace ShoppingCartService.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class ShoppingCartController : ControllerBase
    {
        private readonly IShoppingCartRepository _shoppingCartRepository;

        public ShoppingCartController(IShoppingCartRepository shoppingCartRepository)
        {
            _shoppingCartRepository = shoppingCartRepository;
        }

        [HttpGet("{id}", Name ="Get")]
        public IActionResult GetUserWithCart(int id)
        {
            var user = _shoppingCartRepository.Get(id);
            return new OkObjectResult(user);
        }


        [HttpPost("{id}/items", Name = "Post")]
        public async Task<IActionResult> AddItemsToCart(int id, [FromBody] int[] ids)
        {
            var user = await _shoppingCartRepository.Save(id, ids);
            return new OkObjectResult(user);
        }
    }
}