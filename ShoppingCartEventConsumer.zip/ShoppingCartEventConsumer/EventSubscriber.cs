﻿using Newtonsoft.Json;
using ShoppingCartEventConsumer.Models;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using static System.Console;

namespace ShoppingCartEventConsumer
{
    public class EventSubscriber
    {
        private readonly string pHost;
        private long start = 0, chunkSize = 100;
        private readonly Timer timer;

        public EventSubscriber(string pHost)
        {
            this.pHost = pHost;
            this.timer = new Timer(10 * 1000);
            this.timer.AutoReset = false;
            this.timer.Elapsed += (_, __) => SubscriptionCycleCallback().Wait();
        }

        private async Task SubscriptionCycleCallback()
        {
            var response = await ReadEvents();
            if (response.StatusCode == HttpStatusCode.OK)
                HandleEvents(await response.Content.ReadAsStringAsync());
            this.timer.Start();
        }

        private void HandleEvents(string content)
        {
            var events = JsonConvert.DeserializeObject<IEnumerable<Event>>(content);
            foreach (var ev in events)
            {
                dynamic eventData = ev.Content;
                WriteLine("User ID: " + (string)eventData.userId);
                WriteLine("\t\tProducts: " + (string)eventData.item.productName);
                this.start = Math.Max(this.start, ev.SequenceNumber + 1);
            }
        }

        private async Task<HttpResponseMessage> ReadEvents()
        {
            using (var httpClient = new HttpClient())
            {
                httpClient.BaseAddress = new Uri($"http://{this.pHost}");
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var response = await httpClient.GetAsync("events");
                return response;
            }
        }

        public void Start()
        {
            this.timer.Start();
        }

        public void Stop()
        {
            this.timer.Stop();
        }
    }
}
