﻿using System;

namespace ShoppingCartEventConsumer
{
    class Program
    {
        private static EventSubscriber subscriber;
        static void Main(string[] args)
        {
            subscriber = new EventSubscriber("localhost:54019");
            subscriber.Start();
            Console.WriteLine("Event Consumer Started, press any key to Stop....");
            Console.ReadLine();
            subscriber.Stop();
        }
    }
}
