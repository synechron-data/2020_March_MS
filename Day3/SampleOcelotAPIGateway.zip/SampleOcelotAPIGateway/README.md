# SampleOcelotAPIGateway
This is the demo project for my article "Building .NET Core API Gateway with Ocelot" on Medium. 
You can access fully article here: https://medium.com/@letienthanh0212/building-net-core-api-gateway-with-ocelot-6302c2b3ffc5?sk=f42f184f5b6b350a3350d7c79e391327
