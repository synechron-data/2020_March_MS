﻿namespace RMQ_Demo.Models
{
	public enum PhoneType
	{
			HOMEPHONE, CELLPHONE, WORKPHONE
	}
}
