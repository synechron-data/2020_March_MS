﻿namespace RMQ_Demo.Events
{
	public interface IEvent
    {
    }
}
