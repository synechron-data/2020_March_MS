﻿namespace RMQ_Demo.Events
{
	public class CustomerDeletedEvent : IEvent
	{
		public long Id { get; set; }
	}
}
