﻿using RMQ_Demo.Events;

namespace RMQ_Demo.Commands
{
	public class DeleteCustomerCommand : Command
	{
		internal CustomerDeletedEvent ToCustomerEvent()
		{
			return new CustomerDeletedEvent
			{
				Id = this.Id
			};
		}
	}
}
