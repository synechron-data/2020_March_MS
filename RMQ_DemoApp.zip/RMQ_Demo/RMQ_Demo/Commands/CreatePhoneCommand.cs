﻿using RMQ_Demo.Models;

namespace RMQ_Demo.Commands
{
	public class CreatePhoneCommand : Command
	{
		public PhoneType Type { get; set; }
		public int AreaCode { get; set; }
		public int Number { get; set; }
	}
}
