﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RMQ_Demo.Commands;
using RMQ_Demo.Models;
using RMQ_Demo.Models.Mongo;
using RMQ_Demo.Models.SQLite;

namespace RMQ_Demo.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class CustomersController : Controller
    {
        private readonly ICommandHandler<Command> _commandHandler;
        private readonly CustomerMongoRepository _mongoRepository;
        private readonly CustomerSQLiteRepository _sqliteRepository;

        public CustomersController(ICommandHandler<Command> commandHandler,
            CustomerSQLiteRepository sqliteRepository,
            CustomerMongoRepository repository)
        {
            _commandHandler = commandHandler;
            _sqliteRepository = sqliteRepository;
            _mongoRepository = repository;

            if (_mongoRepository.GetCustomers().Count == 0)
            {
                var customerCmd = new CreateCustomerCommand
                {
                    Name = "Manish Sharma",
                    Email = "m@g.com",
                    Age = 37,
                    Phones = new List<CreatePhoneCommand>
                    {
                        new CreatePhoneCommand { Type = PhoneType.CELLPHONE, AreaCode = 91, Number = 7543010 }
                    }
                };

                _commandHandler.Execute(customerCmd);
            }
        }

        [HttpGet]
        public List<CustomerEntity> Get()
        {
            return _mongoRepository.GetCustomers();
        }

        [HttpGet("{id}", Name = "GetCustomer")]
        public IActionResult GetById(long id)
        {
            var product = _mongoRepository.GetCustomer(id);
            if (product == null)
            {
                return NotFound();
            }

            return new ObjectResult(product);
        }

        [HttpGet("{email}")]
        public IActionResult GetByEmail(string email)
        {
            var product = _mongoRepository.GetCustomerByEmail(email);
            if (product == null)
            {
                return NotFound();
            }

            return new ObjectResult(product);
        }

        [HttpPost]
        public IActionResult Post([FromBody] CreateCustomerCommand customer)
        {
            _commandHandler.Execute(customer);

            return CreatedAtRoute("GetCustomer", new { id = customer.Id }, customer);
        }

        [HttpPut("{id}")]
        public IActionResult Put(long id, [FromBody] UpdateCustomerCommand customer)
        {
            var record = _sqliteRepository.GetById(id);
            if (record == null)
            {
                return NotFound();
            }

            customer.Id = id;
            _commandHandler.Execute(customer);

            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            var record = _sqliteRepository.GetById(id);
            if (record == null)
            {
                return NotFound();
            }

            _commandHandler.Execute(new DeleteCustomerCommand()
            {
                Id = id
            });

            return NoContent();
        }
    }

    //   public class CustomersController : ControllerBase
    //   {
    //	private readonly CustomerSQLiteRepository _sqliteRepository;
    //	public CustomersController(CustomerSQLiteRepository sqliteRepository)
    //	{
    //		_sqliteRepository = sqliteRepository;
    //	}
    //[HttpGet]
    //public IActionResult GetAll()
    //{
    //    //var customers = null;
    //    //if (customers == null)
    //    //{
    //    //	return NotFound();
    //    //}
    //    return new ObjectResult(null);
    //}
    //[HttpGet("{id}", Name = "GetCustomer")]
    //public IActionResult GetById(long id)
    //{
    //    var customer = _sqliteRepository.GetById(id);
    //    if (customer == null)
    //    {
    //        return NotFound();
    //    }
    //    return new ObjectResult(customer);
    //}
    //[HttpPost]
    //public IActionResult Post([FromBody] CustomerRecord customer)
    //{
    //    CustomerRecord created = _sqliteRepository.Create(customer);
    //    return CreatedAtRoute("GetCustomer", new { id = created.Id }, created);
    //}
    //[HttpPut("{id}")]
    //public IActionResult Put(long id, [FromBody] CustomerRecord customer)
    //{
    //    var record = _sqliteRepository.GetById(id);
    //    if (record == null)
    //    {
    //        return NotFound();
    //    }
    //    customer.Id = id;
    //    _sqliteRepository.Update(customer);
    //    return NoContent();
    //}
    //[HttpDelete("{id}")]
    //public IActionResult Delete(long id)
    //{
    //    var record = _sqliteRepository.GetById(id);
    //    if (record == null)
    //    {
    //        return NotFound();
    //    }
    //    _sqliteRepository.Remove(id);
    //    return NoContent();
    //}
    //}
}