﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace ProductMicroservice.Models
{
    public class Price
    {
        [JsonIgnore]
        public int PriceId { get; set; }
        public int Amount { get; set; }
        public string Currency { get; set; }
        [JsonIgnore]
        public int ProductId { get; set; }
        [JsonIgnore]
        public Product Product { get; set; }
    }
}
