﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace ProductMicroservice.Models
{
    public class Attribute
    {
        [JsonIgnore]
        public int AttributeId { get; set; }
        public IEnumerable<string> Sizes { get; set; }
        public IEnumerable<string> Colors { get; set; }
        [JsonIgnore]
        public Product Product { get; set; }
    }
}
