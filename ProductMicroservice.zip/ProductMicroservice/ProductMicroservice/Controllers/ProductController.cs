﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ProductMicroservice.Repository;

namespace ProductMicroservice.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IProductRepository _productRepository;

        public ProductController(IProductRepository productRepository)
        {
            _productRepository = productRepository;
        }

        [HttpGet]
        public IActionResult Get()
        {
            var products = _productRepository.GetProducts();
            return new OkObjectResult(products);
        }

        //[HttpGet("{id}", Name = "Get")]
        //public IActionResult Get(int id)
        //{
        //    var product = _productRepository.GetProductByID(id);
        //    return new OkObjectResult(product);
        //}

        [HttpGet("getm")]
        public IActionResult Get([FromQuery(Name = "ids")]int[] ids)
        {
            var result = (from id in ids
                          let p = _productRepository.GetProductByID(id)
                          where p != null
                          select p).ToList();

            return new OkObjectResult(result);
        }
    }
}