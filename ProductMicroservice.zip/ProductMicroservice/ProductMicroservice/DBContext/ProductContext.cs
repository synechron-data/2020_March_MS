﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using ProductMicroservice.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductMicroservice.DBContext
{
    public class ProductContext : DbContext
    {
        public ProductContext(DbContextOptions<ProductContext> options) : base(options) { }

        public DbSet<Product> Products { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            var splitStringConverter = new ValueConverter<IEnumerable<string>, string>(v => string.Join(";", v), v => v.Split(new[] { ';' }));
            modelBuilder.Entity<Models.Attribute>().Property(nameof(Models.Attribute.Sizes)).HasConversion(splitStringConverter);
            modelBuilder.Entity<Models.Attribute>().Property(nameof(Models.Attribute.Colors)).HasConversion(splitStringConverter);

            modelBuilder.Entity<Product>()
                .HasOne(c => c.Price)
                .WithOne(e => e.Product)
                .HasForeignKey<Price>(c => c.ProductId);

            modelBuilder.Entity<Product>().HasData(
                new Product
                {
                    Id = 1,
                    ProductId = "1",
                    ProductName = "Basic t-shirt",
                    ProductDescription = "a quiet t-shirt"
                },
                new Product
                {
                    Id = 2,
                    ProductId = "2",
                    ProductName = "Fancy shirt",
                    ProductDescription = "a loud t-shirt"
                }
            );

            modelBuilder.Entity<Models.Price>().HasData(
                new
                {
                    PriceId = 1,
                    Amount = 40,
                    Currency = "eur",
                    ProductId = 1
                },
                new
                {
                    PriceId = 2,
                    Amount = 50,
                    Currency = "eur",
                    ProductId = 2
                }
            );

            modelBuilder.Entity<Models.Attribute>().HasData(
                new
                {
                    AttributeId = 1,
                    Sizes = new List<string>() {
                        "s", "m", "l"
                    },
                    Colors = new List<string>() {
                        "red", "blue", "green"
                    },
                    ProductId = 1
                },
                new
                {
                    AttributeId = 2,
                    Sizes = new List<string>() {
                        "s", "m", "l", "xl"
                    },
                    Colors = new List<string>() {
                        "red", "blue", "green", "batique"
                    },
                    ProductId = 2
                }
            );
        }
    }
}
