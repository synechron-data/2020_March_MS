﻿using Microsoft.EntityFrameworkCore;
using ProductMicroservice.DBContext;
using ProductMicroservice.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductMicroservice.Repository
{
    public class ProductRepository : IProductRepository
    {
        private readonly ProductContext _dbContext;

        public ProductRepository(ProductContext dbContext)
        {
            _dbContext = dbContext;
        }
        public void DeleteProduct(int productId)
        {
            throw new NotImplementedException();
        }

        public Product GetProductByID(int productId)
        {
            return _dbContext.Products.Include(p => p.Price)
                .Include(p => p.Attributes).Where(p => p.Id == productId).FirstOrDefault();
        }

        public IEnumerable<Product> GetProducts()
        {
            return _dbContext.Products.Include(p => p.Price)
                .Include(p => p.Attributes).ToList();
        }

        public void InsertProduct(Product product)
        {
            throw new NotImplementedException();
        }

        public void Save()
        {
            throw new NotImplementedException();
        }

        public void UpdateProduct(Product product)
        {
            throw new NotImplementedException();
        }
    }
}
