﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ShoppingCartService.EventsFeed;

namespace ShoppingCartService.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class EventsController : ControllerBase
    {
        private IEventStore _eventStore;

        public EventsController(IEventStore eventStore)
        {
            this._eventStore = eventStore;
        }

        [HttpGet]
        public IActionResult Get([FromQuery]long start = 0, [FromQuery]long end = long.MaxValue)
        {
            return new OkObjectResult(this._eventStore.GetEvents(start, end));
        }
    }
}