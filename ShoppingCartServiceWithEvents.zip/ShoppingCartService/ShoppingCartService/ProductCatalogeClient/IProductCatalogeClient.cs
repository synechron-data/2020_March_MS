﻿using ShoppingCartService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShoppingCartService.ProductCatalogeClient
{
    public interface IProductCatalogeClient
    {
        Task<IEnumerable<ShoppingCartItem>> GetSPItems(int[] pIds);
    }
}
