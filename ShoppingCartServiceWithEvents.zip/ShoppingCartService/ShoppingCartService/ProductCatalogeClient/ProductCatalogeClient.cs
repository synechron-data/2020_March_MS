﻿using Newtonsoft.Json;
using ShoppingCartService.Models;
using ShoppingCartService.Models.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace ShoppingCartService.ProductCatalogeClient
{
    public class ProductCatalogeClient : IProductCatalogeClient
    {
        private static string productCatalogueBaseUrl = @"http://localhost:64016/";
        private static string getProductPathTemplate = @"/product/getm?ids={0}";

        public async Task<IEnumerable<ShoppingCartItem>> GetSPItems(int[] pIds)
        {
            var items = await GetItemsFromCatalogueService(pIds);
            return items;
        }

        private async Task<IEnumerable<ShoppingCartItem>> GetItemsFromCatalogueService(int[] pIds)
        {
            var response = await RequestProductFromProductCatalogue(pIds).ConfigureAwait(false);
            return await ConvertToShoppingCartItems(response).ConfigureAwait(false);
        }

        private static async Task<IEnumerable<ShoppingCartItem>> ConvertToShoppingCartItems(HttpResponseMessage response)
        {
            response.EnsureSuccessStatusCode();
            var products = JsonConvert.DeserializeObject<List<ProductCatalogueProduct>>(
                await response.Content.ReadAsStringAsync().ConfigureAwait(false));
            return products.Select(p => new ShoppingCartItem(
                int.Parse(p.ProductId),
                p.ProductName,
                p.ProductDescription,
                p.Price
            ));
        }

        private async Task<HttpResponseMessage> RequestProductFromProductCatalogue(int[] pIds)
        {
            var productResource = string.Format(getProductPathTemplate, string.Join("&ids=", pIds));
            using (HttpClient httpClient = new HttpClient())
            {
                httpClient.BaseAddress = new Uri(productCatalogueBaseUrl);
                return await httpClient.GetAsync(productResource).ConfigureAwait(false);
            }
        }

        private class ProductCatalogueProduct
        {
            public string ProductId { get; set; }
            public string ProductName { get; set; }
            public string ProductDescription { get; set; }
            public Money Price { get; set; }
        }
    }
}
