﻿using ShoppingCartService.DBContext;
using ShoppingCartService.EventsFeed;
using ShoppingCartService.ProductCatalogeClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShoppingCartService.Repository
{
    public class ShoppingCartRepository : IShoppingCartRepository
    {
        private readonly IProductCatalogeClient _pcClient;
        private readonly IEventStore _eventStore;

        public ShoppingCartRepository(IProductCatalogeClient pcClient, IEventStore eventStore)
        {
            this._pcClient = pcClient;
            this._eventStore = eventStore;
        }

        private static readonly Dictionary<int, ShoppingCartContext> database
           = new Dictionary<int, ShoppingCartContext>();

        public ShoppingCartContext Get(int userID)
        {
            if (!database.ContainsKey(userID))
                database[userID] = new ShoppingCartContext(userID);
            return database[userID];
        }

        public async Task<ShoppingCartContext> Save(int userID, int[] ids)
        {
            var shoppingCartItems = await _pcClient.GetSPItems(ids);

            var db = this.Get(userID);
            db.AddItems(shoppingCartItems, _eventStore);
            return db;
        }
    }
}
