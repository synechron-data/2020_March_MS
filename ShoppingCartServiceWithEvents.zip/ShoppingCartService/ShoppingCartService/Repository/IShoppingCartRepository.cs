﻿using ShoppingCartService.DBContext;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShoppingCartService.Repository
{
    public interface IShoppingCartRepository
    {
        ShoppingCartContext Get(int userID);

        Task<ShoppingCartContext> Save(int userID, int[] ids);
    }
}
